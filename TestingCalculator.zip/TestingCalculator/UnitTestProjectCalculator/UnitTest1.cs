﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace UnitTestProjectCalculator
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MyCalculator answer = new MyCalculator();
            int ans = answer.Add(20, 10);
            Assert.AreEqual(30, ans);
        }
        [TestMethod]
        public void TestMethod2()
        {
            MyCalculator answer = new MyCalculator();
            int ans = answer.Sub(20, 10);
            Assert.AreEqual(10, ans);
        }
        [TestMethod]
        public void TestMethod3()
        {
            MyCalculator answer = new MyCalculator();
            int ans = answer.Mul(20, 10);
            Assert.AreEqual(200, ans);
        }
        [TestMethod]
        public void TestMethod4()
        {
            MyCalculator answer = new MyCalculator();
            int ans = answer.Div(20, 4);
            Assert.AreEqual(5, ans);
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException),"Divide by zero exception")]
        public void TestMethod5()
        {
            MyCalculator answer = new MyCalculator();
            int ans = answer.Div(20, 0);
            
        }
    }
}

