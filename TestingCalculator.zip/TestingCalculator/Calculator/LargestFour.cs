﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   public class LargestFour
    {

        public int Largest4(int x, int y, int z, int a)
        {
            if (x > y && x > z && x>a)
            {
                return x;

            }

            else if (y > x && y > z && y>a)
            {
                return y;

            }

            else if (z > x && z > y && z > a)
            {
                return z;
            }

            else
            {
                return a;
            }

        }
    }
}
