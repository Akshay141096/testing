﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
  public  class ElectricityBill
    {
        public float CalulateBill(int NoOfUnit)
        {
            int minBill = 200;



            if (NoOfUnit > 0 && NoOfUnit < 100)
            {
                return 0.14f * NoOfUnit;
            }
            else if (NoOfUnit >= 100 && NoOfUnit < 200)
            {
                return 0.50f * NoOfUnit * 0.14f;
            }
            else if (NoOfUnit >= 200 && NoOfUnit < 300)
            {
                return (100 / 3) * (1 / 20) * NoOfUnit;
            }
            else if (NoOfUnit >= 300 && NoOfUnit < 400)
            {
                return (100 / 4) * (2 / 25) * NoOfUnit;
            }
            else
            {
               return 6 * NoOfUnit;
            }



        }


    }
}
