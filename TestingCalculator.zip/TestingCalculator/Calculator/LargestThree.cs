﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   public  class LarrgestThree
    {
        public int Largest3(int x, int y, int z)
        {
            if (x > y && x > z)
            {
                return x;

            }

            else if(y > x && y > z)
            {
                return y;

            }

            else
                {
                return z;
                }

        }
    }
}
