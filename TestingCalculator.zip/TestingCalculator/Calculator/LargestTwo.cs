﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class LargestTwo
    {
        public int Largest2(int x, int y)
        {
            if (x > y)
            {
                return x;

            }
            return y;

        }

    }  
}
