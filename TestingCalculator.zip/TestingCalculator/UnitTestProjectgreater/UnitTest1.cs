﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace UnitTestProjectgreater
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            LargestTwo answer = new LargestTwo();
            int ans = answer.Largest2(20, 10);
            Assert.AreEqual(20, ans);
        }
        [TestMethod]
        public void TestMethod2()
        {
            LarrgestThree answer = new LarrgestThree();
            int ans = answer.Largest3(30,20, 10);
            Assert.AreEqual(30, ans);
        }

        public void TestMethod3()
        {
            LargestFour answer = new LargestFour();
            int ans = answer.Largest4(40,30, 20, 10);
            Assert.AreEqual(40, ans);
        }


    }
}
