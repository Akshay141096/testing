﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace electricitybill
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            ElectricityBill answer = new ElectricityBill();
                int ans = Convert.ToInt32(answer.CalulateBill(20));
                Assert.AreEqual(120, ans);
            
        }
    }
}
